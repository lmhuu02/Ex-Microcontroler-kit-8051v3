/*
Nguoi viet: Xuan Hai
Ngay viet: 18/01/2022
Phan mem: mikroC PRO for PIC v6.0.0

Final Proj: Dong ho van nien su dung DS1307 Va cam bien nhiet do LM35

*/
// Oscillator:      XT, 04.0000 MHz
// LCD module connections
sbit LCD_RS at RB4_bit;
sbit LCD_EN at RB5_bit;
sbit LCD_D4 at RB0_bit;
sbit LCD_D5 at RB1_bit;
sbit LCD_D6 at RB2_bit;
sbit LCD_D7 at RB3_bit;

sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;
// End LCD module connections


char txt1[] = "Elec2PCB.com";
char txt2[] = "Lap trinh PIC online";
char txt3[] = "Khoa 1 - 2021";
char txt4[] = "Xin chao!";
char nice_day[] = "Have a nice day!";
char hot_day[] = "Today is hot!";
char cold_day[] = "Today is cold!";
unsigned int adc_rd;
char i;
int temp,date,month,year,hour,minute,second;                           // Loop variable
float nhiet_do = 00.0;
char ngay_thang_nam[]= "DATE: 00-00-00";
char gio_phut_giay[]= "TIME: 00:00:00";

char arr_nhiet_do[] ="TEMP: 00.0 C";
void Move_Delay() {                  // Function used for text moving
  Delay_ms(300);                     // You can change the moving speed here
}
//===============DONG HO THOI GIAN THUC===================
//********************************************************
void write_ds1307(int address,int da_ta)
{
   I2C1_INIT(8000000);
   I2C1_START();
   I2C1_WR(0XD0);
   I2C1_WR(address);
   I2C1_WR(da_ta);
   I2C1_STOP();
}
int read_ds1307(int address)
{
   int da_ta;
   I2C1_INIT(8000000);
   I2C1_START();
   I2C1_WR(0XD0);
   I2C1_WR(address);
   I2C1_REPEATED_START();
   I2C1_WR(0XD1);
   da_ta = I2C1_RD(0);
   I2C1_STOP();
   return(da_ta);
}
void set_date_month_year(int date,int month,int year)
{
   write_ds1307(0x04,date);
   write_ds1307(0x05,month);
   write_ds1307(0x06,year);
}
void set_hours_minute_second(int hours,int minute,int second)
{
   write_ds1307(0x00,second);
   write_ds1307(0x01,minute);
   write_ds1307(0x02,hours);
}
int bcd_to_decimal(int number)
{
   return((number >> 4) * 10 + (number & 0x0F));
}
int decimal_to_bcd(int number)
{
   return(((number / 10) << 4) + (number % 10));
}


void main(){
  ANSEL=0x04;                        // Configure AN pins as digital I/O
  ANSELH = 0;
  TRISA.RA2 = 1;
  C1ON_bit = 0;                      // Disable comparators
  C2ON_bit = 0;

  Lcd_Init();                        // Initialize LCD

  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off
  Lcd_Out(1,5,txt1);                 // Write text in first row

  Lcd_Out(2,1,txt2);                 // Write text in second row
  Delay_ms(1000);
  Lcd_Cmd(_LCD_CLEAR);               // Clear display

  Lcd_Out(1,3,txt3);                 // Write text in first row
  Lcd_Out(2,3,txt4);                 // Write text in second row

  Delay_ms(2000);

  // Moving text
  for(i=0; i<4; i++) {               // Move text to the right 4 times
    Lcd_Cmd(_LCD_SHIFT_RIGHT);
    Move_Delay();
  }
//**********Phan cai dat thoi gian ban dau***************//
   write_ds1307(0x04,0x19);
   write_ds1307(0x05,0x01);
   write_ds1307(0x06,0x23);

   write_ds1307(0x00,0x00);
   write_ds1307(0x01,0x05);
   write_ds1307(0x02,0x16);
   //write_ds1307(0x02,decimal_to_bcd(16));



    //==================VONG LAP VO HAN ==================//
  while(1)
  {

   date=read_ds1307(0x04);
   date= bcd_to_decimal(date);
   month=read_ds1307(0x05);
   month= bcd_to_decimal(month);
   year = read_ds1307(0x06);
    year= bcd_to_decimal(year);
   hour=read_ds1307(0x02);
   hour= bcd_to_decimal(hour);
   minute=read_ds1307(0x01);
    minute= bcd_to_decimal(minute);
   second = read_ds1307(0x00);
    second= bcd_to_decimal(second);

   ngay_thang_nam[6]= (date/10)+48; //16 - 1
   ngay_thang_nam[7]= (date%10)+48; //16 - 6
   ngay_thang_nam[9]= (month/10)+48;
   ngay_thang_nam[10]= (month%10)+48;
   ngay_thang_nam[12]= (year/10)+48;
   ngay_thang_nam[13]= (year%10)+48;
   gio_phut_giay[6]= (hour/10)+48;
   gio_phut_giay[7]= (hour%10)+48;
   gio_phut_giay[9]= (minute/10)+48;
   gio_phut_giay[10]= (minute%10)+48;
   gio_phut_giay[12]= (second/10)+48;
   gio_phut_giay[13]= (second%10)+48;
   Lcd_out(1,1,nice_day);
   Lcd_out(2,1,ngay_thang_nam);
   Lcd_out(3,1,gio_phut_giay);
//**********Phan do nhiet do va hien thi len LCD***************//
   adc_rd = ADC_Read(2);
   nhiet_do = (adc_rd*5)*100/1024.0;       //Volt analog -> digital
   //   FloatToStr(nhiet_do, arr_nhiet_do);
   temp = (int)nhiet_do;
   arr_nhiet_do[6] =temp/10+48;             //So bat dau tu 48 trong ASCII
   arr_nhiet_do[7] =temp%10+48;
   arr_nhiet_do[10] =223;                  // *C
   if(temp>30)
   {
       Lcd_out(1,1,hot_day);
   }
   else if(temp <=30 & temp>15)
   {
        Lcd_out(1,1,nice_day);
   }
   else
   {

       Lcd_out(1,1,cold_day);
   }
   Lcd_out(4,1,arr_nhiet_do);
     // Endless loop
   for(i=0; i<3; i++)
    {  // Move text to the left 3 times
        Lcd_Cmd(_LCD_SHIFT_LEFT);
        Move_Delay();
    }

   for(i=0; i<3; i++)
    { // Move text to the right 3 times
        Lcd_Cmd(_LCD_SHIFT_RIGHT);
        Move_Delay();
    }


    }
}
/*
  1. Diem han che cua project
    - Lay gia tri cua nhiet do parse to integer nen co sai so
    - chua the dieu chinh duoc ngay thang nam luc can
  2. Huong phat trien
    - Su dung nut bam de set thoi gian can thiet
    - Su dung dua vao ket qua tu cam bien nhet do de dieu khien mot so thiet bi khac 
*/