/*
Nguoi viet: Lai Phuoc Son
Email: Elec2PCB@gmail.com
Tai: Elec2PCb.com
Ngay viet: 14/01/2022
Phan mem: mikroC PRO for PIC v6

Bai 8.2: Giao tiep I2C voi DS1307

*/
// Oscillator:      XT, 04.0000 MHz
void write_ds1307(int address,int da_ta){

     I2C1_INIT(8000000);
     I2C1_START();
     I2C1_WR(0XD0);
     I2C1_WR(address);
     I2C1_WR(da_ta);
     I2C1_STOP();
     }
int read_ds1307(int address){
     int da_ta;
     I2C1_INIT(8000000);
     I2C1_START();
     I2C1_WR(0XD0);
     I2C1_WR(address);
     I2C1_REPEATED_START();
     I2C1_WR(0XD1);
     da_ta = I2C1_RD(0);
     I2C1_STOP();
     return(da_ta);
}
void set_date_month_year(int date,int month,int year){
     write_ds1307(0x04,date);
     write_ds1307(0x05,month);
     write_ds1307(0x06,year);
 }
 void set_hours_minute_second(int hours,int minute,int second){
     write_ds1307(0x00,second);
     write_ds1307(0x01,minute);
     write_ds1307(0x02,hours);
 }
void main() {

     ANSEL  = 0;              // Configure AN pins as digital
     ANSELH = 0;

     write_ds1307(0x00,0x01); //second:  1s 0000 0001: bit7(CH)=0->the oscillator is enabled
     write_ds1307(0x01,0x25); //minutes: 25m
     write_ds1307(0x02,0x03); //hours:   3h

     write_ds1307(0x04,0x13); //date:    13
     write_ds1307(0x05,0x01); //month:   01
     write_ds1307(0x06,0x21); //year:    21
     //hoac su dung 2 ham sau
     //set_date_month_year(0x13,0x01,0x22);
     //set_hours_minute_second(0x03,0x28,0x01);

}
