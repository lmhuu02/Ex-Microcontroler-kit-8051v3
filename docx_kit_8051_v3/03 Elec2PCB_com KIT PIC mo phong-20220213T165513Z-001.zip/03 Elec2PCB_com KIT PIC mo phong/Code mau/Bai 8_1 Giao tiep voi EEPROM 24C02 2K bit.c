/*
Nguoi viet: Lai Phuoc Son
Email: Elec2PCB@gmail.com
Tai: Elec2PCb.com
Ngay viet: 15/11/2017
Phan mem: mikroC PRO for PIC v5.0.1

Bai 8_1: Giao tiep voi EEPROM 24C02 2K bit
 Oscillator:      XT, 04.0000 MHz

*/
// Oscillator:      XT, 04.0000 MHz

void main(){
  ANSEL  = 0;                // Configure AN pins as digital I/O
  ANSELH = 0;
  TRISB = 0;                 // Configure PORTB as output
  PORTB = 0;
  Delay_100ms();
  PORTB = 0xff;
  Delay_100ms();
  PORTB = 0;
  Delay_100ms();
  
  I2C1_Init(100000);         // initialize I2C communication
                             //100 kHz and 400 kHz Clock Compatibility

  I2C1_Start();              // issue I2C start signal
  I2C1_Wr(0xA2);             // send byte via I2C  (device address + W)
  I2C1_Wr(2);                // send byte (address of EEPROM location)
  //I2C1_Wr(0xAA);             // send data (data to be written) 10101010
  I2C1_Wr(0xf0);
  I2C1_Stop();               // issue I2C stop signal

  Delay_100ms();

  I2C1_Start();              // issue I2C start signal
  I2C1_Wr(0xA2);             // send byte via I2C  (device address + W)
  I2C1_Wr(2);                // send byte (data address)
  I2C1_Repeated_Start();     // issue I2C signal repeated start
  I2C1_Wr(0xA3);             // send byte (device address + R)
  PORTB = I2C1_Rd(0u);       // Read the data (NO acknowledge)
  I2C1_Stop();               // issue I2C stop signal
  while(1);
}