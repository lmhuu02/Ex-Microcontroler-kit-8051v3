extern code unsigned char font_10x20[];
extern code unsigned char font_12x13ja[];
extern code unsigned char font_12x24[];
extern code unsigned char font_12x24rk[];
extern code unsigned char font_18x18ja[];
extern code unsigned char font_18x18ko[];
extern code unsigned char font_4x6[];
extern code unsigned char font_5x7[];
extern code unsigned char font_5x8[];
extern code unsigned char font_6x10[];
extern code unsigned char font_6x12[];
extern code unsigned char font_6x13B[];
extern code unsigned char font_6x13[];
extern code unsigned char font_6x13O[];
extern code unsigned char font_6x9[];
extern code unsigned char font_7x13B[];
extern code unsigned char font_7x13[];
extern code unsigned char font_7x13O[];
extern code unsigned char font_7x14B[];
extern code unsigned char font_7x14[];
extern code unsigned char font_8x13B[];
extern code unsigned char font_8x13[];
extern code unsigned char font_8x13O[];
extern code unsigned char font_8x16[];
extern code unsigned char font_8x16rk[];
extern code unsigned char font_9x15B[];
extern code unsigned char font_9x15[];
extern code unsigned char font_9x18B[];
extern code unsigned char font_9x18[];
extern code unsigned char font_charB08[];	// "Bitstream Charter Black"
extern code unsigned char font_charB10[];	// "Bitstream Charter Black"
extern code unsigned char font_charB12[];	// "Bitstream Charter Black"
extern code unsigned char font_charB14[];	// "Bitstream Charter Black"
extern code unsigned char font_charB18[];	// "Bitstream Charter Black"
extern code unsigned char font_charB24[];	// "Bitstream Charter Black"
extern code unsigned char font_charBI08[];	// "Bitstream Charter Black Italic"
extern code unsigned char font_charBI10[];	// "Bitstream Charter Black Italic"
extern code unsigned char font_charBI12[];	// "Bitstream Charter Black Italic"
extern code unsigned char font_charBI14[];	// "Bitstream Charter Black Italic"
extern code unsigned char font_charBI18[];	// "Bitstream Charter Black Italic"
extern code unsigned char font_charBI24[];	// "Bitstream Charter Black Italic"
extern code unsigned char font_charI08[];
extern code unsigned char font_charI10[];
extern code unsigned char font_charI12[];
extern code unsigned char font_charI14[];
extern code unsigned char font_charI18[];
extern code unsigned char font_charI24[];
extern code unsigned char font_charR08[];
extern code unsigned char font_charR10[];
extern code unsigned char font_charR12[];
extern code unsigned char font_charR14[];
extern code unsigned char font_charR18[];
extern code unsigned char font_charR24[];
extern code unsigned char font_clB6x10[];
extern code unsigned char font_clB6x12[];
extern code unsigned char font_clB8x10[];
extern code unsigned char font_clB8x12[];
extern code unsigned char font_clB8x13[];
extern code unsigned char font_clB8x14[];
extern code unsigned char font_clB8x16[];
extern code unsigned char font_clB8x8[];
extern code unsigned char font_clB9x15[];
extern code unsigned char font_clI6x12[];
extern code unsigned char font_clI8x8[];
extern code unsigned char font_clR4x6[];
extern code unsigned char font_clR5x10[];
extern code unsigned char font_clR5x6[];
extern code unsigned char font_clR5x8[];
extern code unsigned char font_clR6x10[];
extern code unsigned char font_clR6x12[];
extern code unsigned char font_clR6x13[];
extern code unsigned char font_clR6x6[];
extern code unsigned char font_clR6x8[];
extern code unsigned char font_clR7x10[];
extern code unsigned char font_clR7x12[];
extern code unsigned char font_clR7x14[];
extern code unsigned char font_clR7x8[];
extern code unsigned char font_clR8x10[];
extern code unsigned char font_clR8x12[];
extern code unsigned char font_clR8x13[];
extern code unsigned char font_clR8x14[];
extern code unsigned char font_clR8x16[];
extern code unsigned char font_clR8x8[];
extern code unsigned char font_clR9x15[];
extern code unsigned char font_courB08[];	// "Courier Bold"
extern code unsigned char font_courB10[];	// "Courier Bold"
extern code unsigned char font_courB12[];	// "Courier Bold"
extern code unsigned char font_courB14[];	// "Courier Bold"
extern code unsigned char font_courB18[];	// "Courier Bold"
extern code unsigned char font_courB24[];	// "Courier Bold"
extern code unsigned char font_courBO08[];	// "Courier Bold Oblique"
extern code unsigned char font_courBO10[];	// "Courier Bold Oblique"
extern code unsigned char font_courBO12[];	// "Courier Bold Oblique"
extern code unsigned char font_courBO14[];	// "Courier Bold Oblique"
extern code unsigned char font_courBO18[];	// "Courier Bold Oblique"
extern code unsigned char font_courBO24[];	// "Courier Bold Oblique"
extern code unsigned char font_courO08[];	// "Courier Oblique"
extern code unsigned char font_courO10[];	// "Courier Oblique"
extern code unsigned char font_courO12[];	// "Courier Oblique"
extern code unsigned char font_courO14[];	// "Courier Oblique"
extern code unsigned char font_courO18[];	// "Courier Oblique"
extern code unsigned char font_courO24[];	// "Courier Oblique"
extern code unsigned char font_courR08[];	// "Courier"
extern code unsigned char font_courR10[];	// "Courier"
extern code unsigned char font_courR12[];	// "Courier"
extern code unsigned char font_courR14[];	// "Courier"
extern code unsigned char font_courR18[];	// "Courier"
extern code unsigned char font_courR24[];	// "Courier"
extern code unsigned char font_cu12[];
extern code unsigned char font_cu_alt12[];
extern code unsigned char font_cu_arabic12[];
extern code unsigned char font_cuarabic12[];
extern code unsigned char font_cu_devnag12[];
extern code unsigned char font_cudevnag12[];
extern code unsigned char font_cu_lig12[];
extern code unsigned char font_cu_pua12[];
extern code unsigned char font_cursor[];
extern code unsigned char font_deccurs[];
extern code unsigned char font_decsess[];
extern code unsigned char font_gb16fs[];
extern code unsigned char font_gb16st[];
extern code unsigned char font_gb24st[];
extern code unsigned char font_hanglg16[];
extern code unsigned char font_hanglm16[];
extern code unsigned char font_hanglm24[];
extern code unsigned char font_helvB08[];	// "Helvetica Bold"
extern code unsigned char font_helvB10[];	// "Helvetica Bold"
extern code unsigned char font_helvB12[];	// "Helvetica Bold"
extern code unsigned char font_helvB14[];	// "Helvetica Bold"
extern code unsigned char font_helvB18[];	// "Helvetica Bold"
extern code unsigned char font_helvB24[];	// "Helvetica Bold"
extern code unsigned char font_helvBO08[];	// "Helvetica Bold Oblique"
extern code unsigned char font_helvBO10[];	// "Helvetica Bold Oblique"
extern code unsigned char font_helvBO12[];	// "Helvetica Bold Oblique"
extern code unsigned char font_helvBO14[];	// "Helvetica Bold Oblique"
extern code unsigned char font_helvBO18[];	// "Helvetica Bold Oblique"
extern code unsigned char font_helvBO24[];	// "Helvetica Bold Oblique"
extern code unsigned char font_helvO08[];	// "Helvetica Oblique"
extern code unsigned char font_helvO10[];	// "Helvetica Oblique"
extern code unsigned char font_helvO12[];	// "Helvetica Oblique"
extern code unsigned char font_helvO14[];	// "Helvetica Oblique"
extern code unsigned char font_helvO18[];	// "Helvetica Oblique"
extern code unsigned char font_helvO24[];	// "Helvetica Oblique"
extern code unsigned char font_helvR08[];	// "Helvetica"
extern code unsigned char font_helvR10[];	// "Helvetica"
extern code unsigned char font_helvR12[];	// "Helvetica"
extern code unsigned char font_helvR14[];	// "Helvetica"
extern code unsigned char font_helvR18[];	// "Helvetica"
extern code unsigned char font_helvR24[];	// "Helvetica"
extern code unsigned char font_jiskan16[];
extern code unsigned char font_jiskan24[];
extern code unsigned char font_k14[];
extern code unsigned char font_lubB08[];
extern code unsigned char font_lubB10[];
extern code unsigned char font_lubB12[];
extern code unsigned char font_lubB14[];
extern code unsigned char font_lubB18[];
extern code unsigned char font_lubB19[];
extern code unsigned char font_lubB24[];
extern code unsigned char font_lubBI08[];
extern code unsigned char font_lubBI10[];
extern code unsigned char font_lubBI12[];
extern code unsigned char font_lubBI14[];
extern code unsigned char font_lubBI18[];
extern code unsigned char font_lubBI19[];
extern code unsigned char font_lubBI24[];
extern code unsigned char font_lubI08[];
extern code unsigned char font_lubI10[];
extern code unsigned char font_lubI12[];
extern code unsigned char font_lubI14[];
extern code unsigned char font_lubI18[];
extern code unsigned char font_lubI19[];
extern code unsigned char font_lubI24[];
extern code unsigned char font_luBIS08[];
extern code unsigned char font_luBIS10[];
extern code unsigned char font_luBIS12[];
extern code unsigned char font_luBIS14[];
extern code unsigned char font_luBIS18[];
extern code unsigned char font_luBIS19[];
extern code unsigned char font_luBIS24[];
extern code unsigned char font_lubR08[];
extern code unsigned char font_lubR10[];
extern code unsigned char font_lubR12[];
extern code unsigned char font_lubR14[];
extern code unsigned char font_lubR18[];
extern code unsigned char font_lubR19[];
extern code unsigned char font_lubR24[];
extern code unsigned char font_luBS08[];
extern code unsigned char font_luBS10[];
extern code unsigned char font_luBS12[];
extern code unsigned char font_luBS14[];
extern code unsigned char font_luBS18[];
extern code unsigned char font_luBS19[];
extern code unsigned char font_luBS24[];
extern code unsigned char font_luIS08[];
extern code unsigned char font_luIS10[];
extern code unsigned char font_luIS12[];
extern code unsigned char font_luIS14[];
extern code unsigned char font_luIS18[];
extern code unsigned char font_luIS19[];
extern code unsigned char font_luIS24[];
extern code unsigned char font_luRS08[];
extern code unsigned char font_luRS10[];
extern code unsigned char font_luRS12[];
extern code unsigned char font_luRS14[];
extern code unsigned char font_luRS18[];
extern code unsigned char font_luRS19[];
extern code unsigned char font_luRS24[];
extern code unsigned char font_lutBS08[];
extern code unsigned char font_lutBS10[];
extern code unsigned char font_lutBS12[];
extern code unsigned char font_lutBS14[];
extern code unsigned char font_lutBS18[];
extern code unsigned char font_lutBS19[];
extern code unsigned char font_lutBS24[];
extern code unsigned char font_lutRS08[];
extern code unsigned char font_lutRS10[];
extern code unsigned char font_lutRS12[];
extern code unsigned char font_lutRS14[];
extern code unsigned char font_lutRS18[];
extern code unsigned char font_lutRS19[];
extern code unsigned char font_lutRS24[];
extern code unsigned char font_micro[];
extern code unsigned char font_ncenB08[];	// "New Century Schoolbook Bold"
extern code unsigned char font_ncenB10[];	// "New Century Schoolbook Bold"
extern code unsigned char font_ncenB12[];	// "New Century Schoolbook Bold"
extern code unsigned char font_ncenB14[];	// "New Century Schoolbook Bold"
extern code unsigned char font_ncenB18[];	// "New Century Schoolbook Bold"
extern code unsigned char font_ncenB24[];	// "New Century Schoolbook Bold"
extern code unsigned char font_ncenBI08[];	// "New Century Schoolbook Bold Italic"
extern code unsigned char font_ncenBI10[];	// "New Century Schoolbook Bold Italic"
extern code unsigned char font_ncenBI12[];	// "New Century Schoolbook Bold Italic"
extern code unsigned char font_ncenBI14[];	// "New Century Schoolbook Bold Italic"
extern code unsigned char font_ncenBI18[];	// "New Century Schoolbook Bold Italic"
extern code unsigned char font_ncenBI24[];	// "New Century Schoolbook Bold Italic"
extern code unsigned char font_ncenI08[];	// "New Century Schoolbook Italic"
extern code unsigned char font_ncenI10[];	// "New Century Schoolbook Italic"
extern code unsigned char font_ncenI12[];	// "New Century Schoolbook Italic"
extern code unsigned char font_ncenI14[];	// "New Century Schoolbook Italic"
extern code unsigned char font_ncenI18[];	// "New Century Schoolbook Italic"
extern code unsigned char font_ncenI24[];	// "New Century Schoolbook Italic"
extern code unsigned char font_ncenR08[];	// "New Century Schoolbook Roman"
extern code unsigned char font_ncenR10[];	// "New Century Schoolbook Roman"
extern code unsigned char font_ncenR12[];	// "New Century Schoolbook Roman"
extern code unsigned char font_ncenR14[];	// "New Century Schoolbook Roman"
extern code unsigned char font_ncenR18[];	// "New Century Schoolbook Roman"
extern code unsigned char font_ncenR24[];	// "New Century Schoolbook Roman"
extern code unsigned char font_olcursor[];
extern code unsigned char font_olgl10[];
extern code unsigned char font_olgl12[];
extern code unsigned char font_olgl14[];
extern code unsigned char font_olgl19[];
extern code unsigned char font_symb08[];	// "Symbol"
extern code unsigned char font_symb10[];	// "Symbol"
extern code unsigned char font_symb12[];	// "Symbol"
extern code unsigned char font_symb14[];	// "Symbol"
extern code unsigned char font_symb18[];	// "Symbol"
extern code unsigned char font_symb24[];	// "Symbol"
extern code unsigned char font_tech14[];	// "Terminal"
extern code unsigned char font_techB14[];	// "Terminal Bold"
extern code unsigned char font_term14[];	// "Terminal"
extern code unsigned char font_termB14[];	// "Terminal Bold"
extern code unsigned char font_timB08[];	// "Times Bold"
extern code unsigned char font_timB10[];	// "Times Bold"
extern code unsigned char font_timB12[];	// "Times Bold"
extern code unsigned char font_timB14[];	// "Times Bold"
extern code unsigned char font_timB18[];	// "Times Bold"
extern code unsigned char font_timB24[];	// "Times Bold"
extern code unsigned char font_timBI08[];	// "Times Bold Italic"
extern code unsigned char font_timBI10[];	// "Times Bold Italic"
extern code unsigned char font_timBI12[];	// "Times Bold Italic"
extern code unsigned char font_timBI14[];	// "Times Bold Italic"
extern code unsigned char font_timBI18[];	// "Times Bold Italic"
extern code unsigned char font_timBI24[];	// "Times Bold Italic"
extern code unsigned char font_timI08[];	// "Times Italic"
extern code unsigned char font_timI10[];	// "Times Italic"
extern code unsigned char font_timI12[];	// "Times Italic"
extern code unsigned char font_timI14[];	// "Times Italic"
extern code unsigned char font_timI18[];	// "Times Italic"
extern code unsigned char font_timI24[];	// "Times Italic"
extern code unsigned char font_timR08[];	// "Times Roman"
extern code unsigned char font_timR10[];	// "Times Roman"
extern code unsigned char font_timR12[];	// "Times Roman"
extern code unsigned char font_timR14[];	// "Times Roman"
extern code unsigned char font_timR18[];	// "Times Roman"
extern code unsigned char font_timR24[];	// "Times Roman"
